const $=id=>document.getElementById(id);
function set(id,v){if($(id))$(id).textContent=v}
async function update(){
  try{
    const d=await fetch('/api/telemetry').then(r=>r.json());
    set('clock',new Date().toLocaleTimeString()); set('status',d.rover.status); set('mode',d.rover.mode);
    set('speed',d.rover.speed); set('heading',String(d.rover.heading).padStart(3,'0')+'°');
    set('ambient_temp',d.environment.ambient_temp); set('humidity',d.environment.humidity);
    set('gas_ppm',d.environment.gas_ppm); set('gas_status',d.environment.gas_status);
    $('gas_bar').style.width=Math.min(100,d.environment.gas_ppm)+'%'; set('enclosure_temp',d.environment.enclosure_temp);
    set('thermal_max',d.thermal.max+'°C'); set('thermal2',d.thermal.max);
    ['front','rear','left','right'].forEach(k=>set(k,d.proximity[k]+' m'));
    set('payload_weight',d.payload.weight); set('payload_util',d.payload.utilization+'%'); $('payload_bar').style.width=d.payload.utilization+'%';
    set('soc',d.power.soc+'%'); set('voltage',d.power.voltage+' V'); set('current',d.power.current+' A');
    set('power',d.power.power+' kW'); set('runtime',d.power.runtime); set('reserve',Math.round(d.power.soc-d.power.return_required)+'%');
    set('signal',d.comms.signal+'%'); set('latency',d.comms.latency+' ms'); set('packet_loss',d.comms.packet_loss+'%');
    set('video_latency',d.comms.video_latency+' ms'); set('cpu',d.system.cpu+'%');
    $('subsystems').innerHTML=d.subsystems.map(x=>`<div class="system-row"><span>${x[0]}</span><b class="${x[1].toLowerCase()}">${x[1]}</b></div>`).join('');
  }catch(e){set('status','LINK LOST')}
}
update(); setInterval(update,1000);