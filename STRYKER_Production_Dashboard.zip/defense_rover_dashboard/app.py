from flask import Flask, render_template, jsonify
from datetime import datetime
import random, math

app = Flask(__name__)
tick = 0

def telemetry():
    global tick
    tick += 1
    battery = max(0, 78 - tick * 0.01)
    gas = max(0, 18 + 7 * math.sin(tick / 8) + random.uniform(-2, 2))
    return {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "rover": {
            "name": "STRYKER", "status": "ONLINE", "mode": "ASSISTED",
            "mission": "PERIMETER RECON", "mission_time": "01:42:18",
            "speed": round(1.4 + random.uniform(-0.08, 0.08), 2),
            "heading": 42, "roll": round(2.1 + random.uniform(-0.4, 0.4), 1),
            "pitch": round(4.7 + random.uniform(-0.4, 0.4), 1),
            "stability": "SAFE", "lat": 11.2588, "lon": 75.7804,
            "distance_home": 1.84
        },
        "environment": {
            "ambient_temp": round(31.8 + random.uniform(-0.3, 0.3), 1),
            "humidity": round(72 + random.uniform(-1, 1), 1),
            "gas_ppm": round(gas, 1),
            "gas_status": "SAFE" if gas < 35 else "WARNING",
            "enclosure_temp": round(39.2 + random.uniform(-0.4, 0.4), 1),
            "enclosure_humidity": round(51 + random.uniform(-1, 1), 1)
        },
        "thermal": {
            "min": 26.4, "avg": 34.8,
            "max": round(57.6 + random.uniform(-1, 1), 1),
            "crosshair": round(38.4 + random.uniform(-0.8, 0.8), 1),
            "hotspot_bearing": 42
        },
        "power": {
            "soc": round(battery, 1), "soh": 96, "voltage": 25.9,
            "current": round(43 + random.uniform(-3, 3), 1),
            "power": round(1.12 + random.uniform(-0.08, 0.08), 2),
            "runtime": "2h 14m", "return_required": 23,
            "battery_temp": round(36.2 + random.uniform(-0.3, 0.3), 1),
            "cell_min": 3.21, "cell_max": 3.25, "imbalance_mv": 40
        },
        "proximity": {
            "front": round(3.8 + random.uniform(-0.2, 0.2), 1),
            "rear": 5.6, "left": 2.4, "right": 0.74,
            "nearest": 0.74, "direction": "FRONT RIGHT", "risk": "CAUTION"
        },
        "payload": {"weight": 247, "capacity": 320, "utilization": 77, "status": "SECURED"},
        "comms": {
            "primary": "5G / MESH", "signal": 82,
            "latency": round(46 + random.uniform(-6, 6)),
            "packet_loss": round(max(0, random.uniform(0.1, 1.2)), 1),
            "video_latency": round(118 + random.uniform(-10, 10))
        },
        "system": {
            "cpu": round(42 + random.uniform(-5, 5)),
            "ram": 58, "storage": 41, "cpu_temp": 54,
            "ros_nodes": "18/18", "fps": 24
        },
        "subsystems": [
            ["Main Computer", "HEALTHY"], ["Motor Controller", "HEALTHY"],
            ["Thermal Camera", "HEALTHY"], ["Night Vision", "HEALTHY"],
            ["LiDAR", "DEGRADED"], ["Ultrasonic Array", "HEALTHY"],
            ["Environmental Sensors", "HEALTHY"], ["BMS", "WARNING"],
            ["Communications", "HEALTHY"]
        ]
    }

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/telemetry")
def api_telemetry():
    return jsonify(telemetry())

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
