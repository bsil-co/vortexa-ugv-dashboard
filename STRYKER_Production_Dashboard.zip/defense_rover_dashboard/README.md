# STRYKER Tactical Rover Dashboard

## Run
1. Install Python 3.10+
2. Open a terminal in this folder
3. Run:
   pip install -r requirements.txt
   python app.py
4. Open http://localhost:5000

## Server deployment
For a production server, run behind Gunicorn/Nginx and replace the mock
`telemetry()` function with your ROS 2 / MQTT / WebSocket telemetry bridge.

Example:
  gunicorn -w 2 -b 0.0.0.0:5000 app:app

## Structure
- app.py: Flask server and telemetry API
- templates/index.html: operator dashboard
- static/style.css: responsive tactical UI
- static/app.js: live 1 Hz telemetry updates

Important: Emergency Stop and motion controls in this prototype are UI-only.
For real deployment, use an independent safety-rated hardware E-stop path.
