const $=id=>document.getElementById(id); const set=(id,v)=>{$(id)&&($(id).textContent=v)};
let history=Array.from({length:34},()=>35+Math.random()*45);
function drawBars(){const c=$('powerChart');if(!c)return;c.innerHTML=history.map(v=>`<i style="height:${v}%"></i>`).join('')}
function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),1800)}
async function update(){
 try{
  const d=await fetch('/api/telemetry').then(r=>r.json());
  set('clock',new Date().toLocaleTimeString([], {hour12:false}));set('mode',d.rover.mode);set('speed',d.rover.speed);set('heading',String(d.rover.heading).padStart(3,'0')+'°');
  set('ambient_temp',d.environment.ambient_temp);set('humidity',d.environment.humidity);set('gas_ppm',d.environment.gas_ppm);set('gas_status',d.environment.gas_status);
  set('thermal_max',d.thermal.max+'°C');['front','rear','left','right'].forEach(k=>set(k,d.proximity[k]+' m'));set('payload_weight',d.payload.weight);
  set('soc',d.power.soc+'%');set('voltage',d.power.voltage+' V');set('current',d.power.current+' A');set('power',d.power.power+' kW');set('runtime',d.power.runtime);
  $('batteryFill').style.height=d.power.soc+'%';set('signal',d.comms.signal+'%');set('latency',d.comms.latency+' ms');set('packet_loss',d.comms.packet_loss+'%');set('video_latency',d.comms.video_latency+' ms');set('cpu',d.system.cpu+'%');
  $('subsystems').innerHTML=d.subsystems.map(x=>`<div class="system-row"><span>${x[0]}</span><b class="${x[1].toLowerCase()}">${x[1]}</b></div>`).join('');
  history.push(Math.min(95,Math.max(12,d.power.power*45+Math.random()*15)));history.shift();drawBars();
 }catch(e){toast('UPLINK LOST — RETRYING')}
}
document.addEventListener('DOMContentLoaded',()=>{
 drawBars();const boot=$('boot'),bt=$('bootText');const steps=['ESTABLISHING SECURE COMMAND LINK','AUTHENTICATING OPERATOR','SYNCING SENSOR ARRAY','LOADING MISSION DATA','ALL SYSTEMS OPERATIONAL'];let i=0;
 const timer=setInterval(()=>{if(i<steps.length)bt.textContent=steps[i++];else{clearInterval(timer);boot.classList.add('done')}},420);
 document.querySelectorAll('.nav').forEach(b=>b.onclick=()=>{document.querySelectorAll('.nav').forEach(x=>x.classList.remove('active'));b.classList.add('active');toast(b.dataset.page.toUpperCase()+' CHANNEL SELECTED')});
 document.querySelectorAll('.mode-tabs button').forEach(b=>b.onclick=()=>{document.querySelectorAll('.mode-tabs button').forEach(x=>x.classList.remove('active'));b.classList.add('active');toast(b.textContent+' OPTICS ACTIVE')});
 $('fullCam').onclick=()=>{const c=$('cameraView');document.fullscreenElement?document.exitFullscreen():c.requestFullscreen()};
 document.addEventListener('mousemove',e=>{const g=$('cursorGlow');g.style.left=e.clientX+'px';g.style.top=e.clientY+'px'});
});
update();setInterval(update,1000);